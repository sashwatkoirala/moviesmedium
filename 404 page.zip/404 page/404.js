var a = Nothing;
var b = LOL;
console.log(a + b)